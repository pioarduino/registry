__version__="4.7.0"
__copyright__="Copyright (c) 2001 - 2024 The SCons Foundation"
__developer__="bdbaddog"
__date__="Sun, 17 Mar 2024 17:33:54 -0700"
__buildsys__="M1Dog2021"
__revision__="265be6883fadbb5a545612265acc919595158366"
__build__="265be6883fadbb5a545612265acc919595158366"
# make sure compatibility is always in place
import SCons.compat  # noqa